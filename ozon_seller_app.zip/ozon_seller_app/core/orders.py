"""
orders.py
Получение заказов (отправлений FBS) и превращение их в плоскую таблицу
для дальнейшего формирования листа отгрузки.
"""
from __future__ import annotations

import pandas as pd

from core.api_client import OzonClient


def fetch_orders_dataframe(client: OzonClient) -> pd.DataFrame:
    """
    Тянет необработанные отправления и разворачивает их в плоскую таблицу
    (один товар в отправлении = одна строка).
    """
    postings = client.get_unfulfilled_postings()

    rows = []
    for posting in postings:
        posting_number = posting.get("posting_number")
        status = posting.get("status")
        shipment_date = posting.get("shipment_date")
        warehouse = (posting.get("analytics_data") or {}).get("warehouse_name")

        for product in posting.get("products", []):
            rows.append({
                "posting_number": posting_number,
                "status": status,
                "shipment_date": shipment_date,
                "warehouse": warehouse,
                "offer_id": product.get("offer_id"),      # артикул продавца
                "sku": product.get("sku"),
                "name": product.get("name"),
                "quantity": product.get("quantity"),
                "price": product.get("price"),
            })

    df = pd.DataFrame(rows)
    return df
