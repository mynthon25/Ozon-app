"""
api_client.py
Тонкая обёртка над Ozon Seller API.

Официальная документация (проверяй перед боевым запуском, т.к. Ozon
периодически обновляет методы): https://docs.ozon.ru/api/seller/

Авторизация — заголовки Client-Id и Api-Key, которые продавец получает
в личном кабинете: Настройки -> Seller API.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Optional

import requests

from core.config_manager import Account

BASE_URL = "https://api-seller.ozon.ru"
logger = logging.getLogger("ozon_api")


class OzonApiError(Exception):
    pass


class OzonClient:
    def __init__(self, account: Account, timeout: int = 30):
        self.account = account
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Client-Id": account.client_id,
            "Api-Key": account.api_key,
            "Content-Type": "application/json",
        })

    # -- низкоуровневый вызов с ретраями на 429/5xx -------------------------
    def _post(self, path: str, payload: dict, retries: int = 3) -> dict:
        url = f"{BASE_URL}{path}"
        last_err = None
        for attempt in range(1, retries + 1):
            try:
                resp = self.session.post(url, json=payload, timeout=self.timeout)
                if resp.status_code == 429:
                    wait = 2 ** attempt
                    logger.warning("429 от Ozon (%s), кабинет %s. Пауза %sс", path, self.account.name, wait)
                    time.sleep(wait)
                    continue
                resp.raise_for_status()
                return resp.json()
            except requests.RequestException as e:
                last_err = e
                logger.warning("Ошибка запроса %s (попытка %s/%s): %s", path, attempt, retries, e)
                time.sleep(1.5 * attempt)
        raise OzonApiError(f"Не удалось выполнить {path} после {retries} попыток: {last_err}")

    # -- Заказы (FBS) ---------------------------------------------------
    def get_unfulfilled_postings(self, limit: int = 100) -> list[dict]:
        """
        Возвращает необработанные отправления FBS (готовые к сборке/отгрузке).
        Метод: POST /v3/posting/fbs/unfulfilled/list
        """
        postings: list[dict] = []
        offset = 0
        while True:
            payload = {
                "dir": "ASC",
                "filter": {},
                "limit": limit,
                "offset": offset,
                "with": {"analytics_data": True, "financial_data": False},
            }
            data = self._post("/v3/posting/fbs/unfulfilled/list", payload)
            result = data.get("result", {})
            chunk = result.get("postings", [])
            postings.extend(chunk)
            if len(chunk) < limit:
                break
            offset += limit
        return postings

    # -- Этикетки / бирки -------------------------------------------------
    def get_package_labels_pdf(self, posting_numbers: list[str]) -> bytes:
        """
        Возвращает PDF с бирками (упаковочными листами) для списка отправлений.
        Метод: POST /v2/posting/fbs/package-label
        Ответ приходит НЕ в JSON, а сразу бинарным PDF.
        """
        url = f"{BASE_URL}/v2/posting/fbs/package-label"
        resp = self.session.post(url, json={"posting_number": posting_numbers}, timeout=self.timeout)
        resp.raise_for_status()
        return resp.content

    # -- Остатки ------------------------------------------------------------
    def get_stocks(self, limit: int = 1000) -> list[dict]:
        """
        Возвращает текущие остатки товаров продавца.
        Метод: POST /v4/product/info/stocks (актуальная версия на момент написания).
        """
        items: list[dict] = []
        last_id = ""
        while True:
            payload = {"filter": {}, "last_id": last_id, "limit": limit}
            data = self._post("/v4/product/info/stocks", payload)
            result = data.get("result", {})
            chunk = result.get("items", [])
            items.extend(chunk)
            last_id = result.get("last_id", "")
            if not last_id or not chunk:
                break
        return items

    def update_stocks(self, updates: list[dict]) -> dict:
        """
        Обновляет остатки товаров.
        updates: [{"offer_id": "SKU-1", "stock": 10, "warehouse_id": 123}, ...]
        Метод: POST /v2/products/stocks
        """
        return self._post("/v2/products/stocks", {"stocks": updates})

    # -- Каталог товаров (для сопоставления наименований) --------------------
    def get_product_catalog(self, limit: int = 1000) -> list[dict]:
        """
        Возвращает список товаров продавца [{"offer_id":..., "product_id":..., "name":...}, ...]
        Собирается из двух методов: /v3/product/list (список id) +
        /v3/product/info/list (карточки с наименованием), пачками по 100 id
        (ограничение метода info/list).
        """
        product_ids: list[int] = []
        last_id = ""
        while True:
            payload = {"filter": {}, "last_id": last_id, "limit": limit}
            data = self._post("/v3/product/list", payload)
            result = data.get("result", {})
            items = result.get("items", [])
            product_ids.extend(item.get("product_id") for item in items)
            last_id = result.get("last_id", "")
            if not last_id or not items:
                break

        catalog: list[dict] = []
        for i in range(0, len(product_ids), 100):
            batch = product_ids[i:i + 100]
            data = self._post("/v3/product/info/list", {"product_id": batch})
            for item in data.get("result", {}).get("items", []):
                catalog.append({
                    "offer_id": item.get("offer_id"),
                    "product_id": item.get("id") or item.get("product_id"),
                    "name": item.get("name"),
                })
        return catalog
