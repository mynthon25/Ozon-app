"""
config_manager.py
Хранит список кабинетов Ozon Seller (Client-Id + Api-Key) в зашифрованном
локальном файле. Ключ шифрования генерируется один раз на конкретном
компьютере и хранится рядом (secret.key) — так конфиг нельзя прочитать,
просто скопировав json на другой компьютер без ключа.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional

from cryptography.fernet import Fernet

APP_DIR = Path(os.getenv("APPDATA", Path.home())) / "OzonSellerApp"
APP_DIR.mkdir(parents=True, exist_ok=True)

KEY_FILE = APP_DIR / "secret.key"
ACCOUNTS_FILE = APP_DIR / "accounts.enc"


def _get_or_create_key() -> bytes:
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    KEY_FILE.write_bytes(key)
    return key


_fernet = Fernet(_get_or_create_key())


@dataclass
class Account:
    name: str            # произвольное имя кабинета для GUI, напр. "Магазин №1"
    client_id: str        # Client-Id из личного кабинета Ozon
    api_key: str          # Api-Key из личного кабинета Ozon
    warehouse_id: Optional[int] = None  # склад по умолчанию для остатков (опционально)
    schedule_cron: Optional[str] = None  # напр. "*/30 * * * *" — забирать заказы каждые 30 мин
    output_dir: Optional[str] = None     # куда сохранять листы отгрузки/бирки для этого кабинета


class ConfigManager:
    def __init__(self):
        self.accounts: List[Account] = []
        self.load()

    def load(self) -> None:
        if not ACCOUNTS_FILE.exists():
            self.accounts = []
            return
        raw = _fernet.decrypt(ACCOUNTS_FILE.read_bytes())
        data = json.loads(raw.decode("utf-8"))
        self.accounts = [Account(**item) for item in data]

    def save(self) -> None:
        data = [asdict(a) for a in self.accounts]
        raw = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        ACCOUNTS_FILE.write_bytes(_fernet.encrypt(raw))

    def add_account(self, account: Account) -> None:
        self.accounts.append(account)
        self.save()

    def update_account(self, index: int, account: Account) -> None:
        self.accounts[index] = account
        self.save()

    def remove_account(self, index: int) -> None:
        del self.accounts[index]
        self.save()

    def get_account(self, name: str) -> Optional[Account]:
        return next((a for a in self.accounts if a.name == name), None)
