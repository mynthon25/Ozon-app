"""
stock.py
Экспорт текущих остатков в Excel и обновление остатков в Ozon из Excel-файла.
Формат файла для обновления: колонки offer_id, stock, warehouse_id (последняя опциональна,
если в аккаунте задан warehouse_id по умолчанию).
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd

from core.api_client import OzonClient
from core.config_manager import Account
from core.product_mapping import ProductMapping, build_resolution_plan

# Возможные названия колонок в файле пользователя (файл может быть от любого
# поставщика/учётной системы, поэтому ищем по нескольким вариантам).
NAME_COLUMNS = ["название", "наименование", "товар", "name", "product", "продукт"]
STOCK_COLUMNS = ["остаток", "количество", "кол-во", "stock", "qty", "quantity"]


def _find_column(columns: list[str], candidates: list[str]) -> str | None:
    lowered = {c.lower().strip(): c for c in columns}
    for cand in candidates:
        if cand in lowered:
            return lowered[cand]
    # частичное совпадение, если точного нет
    for col_lower, original in lowered.items():
        if any(cand in col_lower for cand in candidates):
            return original
    return None


def read_user_stock_file(file_path: str) -> pd.DataFrame:
    """
    Читает файл остатков пользователя (Excel), сам определяет колонки с
    названием товара и количеством, возвращает DataFrame с колонками
    user_name / stock.
    """
    df = pd.read_excel(file_path)
    name_col = _find_column(list(df.columns), NAME_COLUMNS)
    stock_col = _find_column(list(df.columns), STOCK_COLUMNS)

    if not name_col or not stock_col:
        raise ValueError(
            "Не удалось определить колонки в файле. "
            f"Найдены колонки: {list(df.columns)}. "
            f"Ожидались название товара (например: {NAME_COLUMNS}) "
            f"и количество (например: {STOCK_COLUMNS})."
        )

    result = df[[name_col, stock_col]].rename(columns={name_col: "user_name", stock_col: "stock"})
    result = result.dropna(subset=["user_name"])
    result["stock"] = pd.to_numeric(result["stock"], errors="coerce").fillna(0).astype(int)
    return result.reset_index(drop=True)


def build_mapping_plan(client: OzonClient, account: Account, file_path: str) -> dict:
    """
    Первый шаг импорта остатков из файла пользователя:
      - читает файл
      - подтягивает каталог товаров кабинета
      - для каждого названия смотрит, есть ли уже подтверждённое соответствие
      - для новых названий подбирает до 3 кандидатов по схожести текста

    Возвращает всё, что нужно GUI, чтобы показать пользователю диалог
    подтверждения только для НОВЫХ/несопоставленных названий.
    """
    user_df = read_user_stock_file(file_path)
    catalog = client.get_product_catalog()
    mapping = ProductMapping(account.name)
    plan = build_resolution_plan(user_df["user_name"].tolist(), catalog, mapping)
    return {
        "user_df": user_df,
        "catalog": catalog,
        "already_mapped": plan["already_mapped"],
        "needs_review": plan["needs_review"],
    }


def apply_confirmed_mapping_and_update(
    client: OzonClient,
    account: Account,
    user_df: pd.DataFrame,
    confirmed: dict[str, dict],
) -> dict:
    """
    confirmed: {user_name: {"offer_id": ..., "ozon_name": ...}, ...}
    Полный набор соответствий на все названия из файла (и уже сохранённые
    ранее, и только что подтверждённые пользователем). Сохраняет новые
    подтверждения в ProductMapping и отправляет обновление остатков в Ozon.
    """
    mapping = ProductMapping(account.name)

    updates = []
    skipped = []
    for _, row in user_df.iterrows():
        match = confirmed.get(row["user_name"])
        if not match or not match.get("offer_id"):
            skipped.append(row["user_name"])
            continue
        # сохраняем/обновляем подтверждение, чтобы в следующий раз не спрашивать снова
        mapping.confirm(row["user_name"], match["offer_id"], match.get("ozon_name", ""))
        item = {"offer_id": str(match["offer_id"]), "stock": int(row["stock"])}
        if account.warehouse_id:
            item["warehouse_id"] = int(account.warehouse_id)
        updates.append(item)

    if not updates:
        return {"updated": 0, "skipped": skipped}

    if any("warehouse_id" not in u for u in updates):
        raise ValueError("Для кабинета не задан склад по умолчанию (warehouse_id) — укажи его в карточке кабинета")

    results = []
    for i in range(0, len(updates), 100):
        batch = updates[i:i + 100]
        results.append(client.update_stocks(batch))

    return {"updated": len(updates), "skipped": skipped, "responses": results}


def export_stocks_to_excel(client: OzonClient, output_dir: str, account_name: str) -> Path:
    items = client.get_stocks()
    rows = []
    for item in items:
        for stock in item.get("stocks", []):
            rows.append({
                "offer_id": item.get("offer_id"),
                "sku": item.get("sku") or item.get("product_id"),
                "warehouse_id": stock.get("warehouse_id") or stock.get("type"),
                "present": stock.get("present"),
                "reserved": stock.get("reserved"),
            })

    df = pd.DataFrame(rows)
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    out_path = out_dir / f"Остатки_{account_name}_{timestamp}.xlsx"
    df.to_excel(out_path, index=False)
    return out_path


def update_stocks_from_excel(client: OzonClient, account: Account, excel_path: str) -> dict:
    df = pd.read_excel(excel_path)
    required = {"offer_id", "stock"}
    if not required.issubset(df.columns):
        raise ValueError(f"В файле должны быть колонки: {required}")

    updates = []
    for _, row in df.iterrows():
        warehouse_id = row["warehouse_id"] if "warehouse_id" in df.columns and pd.notna(row.get("warehouse_id")) else account.warehouse_id
        if warehouse_id is None:
            raise ValueError(f"Не указан warehouse_id для offer_id={row['offer_id']} и в аккаунте по умолчанию его тоже нет")
        updates.append({
            "offer_id": str(row["offer_id"]),
            "stock": int(row["stock"]),
            "warehouse_id": int(warehouse_id),
        })

    # Ozon принимает пачками до 100 позиций за запрос
    results = []
    for i in range(0, len(updates), 100):
        batch = updates[i:i + 100]
        results.append(client.update_stocks(batch))
    return {"batches": len(results), "total_items": len(updates), "responses": results}
