"""
product_mapping.py
Соответствия между "внешними" наименованиями товаров (как их называет
пользователь в своём файле остатков) и offer_id/наименованием в личном
кабинете Ozon.

Логика:
  1. При первой загрузке файла для каждого нового названия ищем до 3
     похожих товаров в каталоге Ozon (по схожести текста).
  2. Пользователь в диалоге подтверждает/выбирает правильный вариант.
  3. Подтверждённое соответствие сохраняется на диск (per-кабинет) и
     дальше применяется автоматически — спрашиваем только про новые,
     ещё не встречавшиеся названия.
"""
from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass, asdict
from typing import Optional

from core.config_manager import APP_DIR

MAPPINGS_DIR = APP_DIR / "mappings"
MAPPINGS_DIR.mkdir(parents=True, exist_ok=True)


def _normalize(text: str) -> str:
    text = (text or "").lower().strip()
    text = re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text)
    return text


def _safe_filename(name: str) -> str:
    return re.sub(r"[^\w\-]+", "_", name, flags=re.UNICODE)


@dataclass
class MappingEntry:
    user_name: str    # название товара в файле пользователя (как есть, для отображения)
    offer_id: str      # артикул (offer_id) в личном кабинете Ozon
    ozon_name: str      # наименование в Ozon на момент сопоставления (для сверки при повторном показе)


class ProductMapping:
    """Хранилище подтверждённых соответствий для одного кабинета."""

    def __init__(self, account_name: str):
        self.account_name = account_name
        self._path = MAPPINGS_DIR / f"{_safe_filename(account_name)}.json"
        self.entries: dict[str, MappingEntry] = {}
        self.load()

    def load(self) -> None:
        if not self._path.exists():
            self.entries = {}
            return
        raw = json.loads(self._path.read_text(encoding="utf-8"))
        self.entries = {k: MappingEntry(**v) for k, v in raw.items()}

    def save(self) -> None:
        data = {k: asdict(v) for k, v in self.entries.items()}
        self._path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def get(self, user_name: str) -> Optional[MappingEntry]:
        return self.entries.get(_normalize(user_name))

    def confirm(self, user_name: str, offer_id: str, ozon_name: str) -> None:
        self.entries[_normalize(user_name)] = MappingEntry(
            user_name=user_name, offer_id=offer_id, ozon_name=ozon_name
        )
        self.save()

    def remove(self, user_name: str) -> None:
        self.entries.pop(_normalize(user_name), None)
        self.save()


def suggest_candidates(user_name: str, catalog: list[dict], max_candidates: int = 3, cutoff: float = 0.35) -> list[dict]:
    """
    catalog: [{"offer_id":..., "name":...}, ...] — весь каталог кабинета.
    Возвращает до max_candidates наиболее похожих товаров, отсортированных
    по убыванию схожести названий (0..1). Используется, чтобы ПРЕДЛОЖИТЬ
    пользователю вариант — окончательный выбор всегда за пользователем.
    """
    norm_user = _normalize(user_name)
    scored = []
    for item in catalog:
        norm_catalog = _normalize(item.get("name", ""))
        if not norm_catalog:
            continue
        ratio = difflib.SequenceMatcher(None, norm_user, norm_catalog).ratio()
        # бонус, если одно из названий буквально содержится в другом
        # (частое совпадение частей наименований у продавцов)
        if norm_user in norm_catalog or norm_catalog in norm_user:
            ratio = max(ratio, 0.85)
        if ratio >= cutoff:
            scored.append({**item, "score": round(ratio, 3)})
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:max_candidates]


def build_resolution_plan(user_names: list[str], catalog: list[dict], mapping: ProductMapping) -> dict:
    """
    Делит список названий пользователя на:
      - already_mapped: уже подтверждённые ранее соответствия (применяются молча)
      - needs_review: новые названия + до 3 предложенных кандидатов на каждое
        (нужно подтверждение пользователя в GUI)
    """
    already_mapped = []
    needs_review = []
    for name in user_names:
        existing = mapping.get(name)
        if existing:
            already_mapped.append({"user_name": name, "offer_id": existing.offer_id, "ozon_name": existing.ozon_name})
        else:
            candidates = suggest_candidates(name, catalog)
            needs_review.append({"user_name": name, "candidates": candidates})
    return {"already_mapped": already_mapped, "needs_review": needs_review}
