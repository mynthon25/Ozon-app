"""
shipment.py
Форматирование итоговых файлов:
  1) "Лист отгрузки" — Excel, отсортированный по наименованию товара,
     со сводкой количеств для сборки.
  2) "Бирки" — PDF с этикетками, полученный напрямую от Ozon API,
     сохраняется как есть (Ozon уже формирует их в печатном виде).
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from core.api_client import OzonClient


def build_shipment_sheet(df: pd.DataFrame, output_dir: str, account_name: str) -> Path:
    """
    Строит лист отгрузки:
      - сортировка по наименованию товара (name) по алфавиту
      - сводная таблица: наименование / артикул / кол-во к сборке
      - подробная таблица по отправлениям ниже
    Возвращает путь к сохранённому .xlsx
    """
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if df.empty:
        raise ValueError("Нет заказов для формирования листа отгрузки")

    df_sorted = df.sort_values(by=["name", "offer_id"], kind="stable").reset_index(drop=True)

    summary = (
        df_sorted.groupby(["name", "offer_id"], as_index=False)["quantity"]
        .sum()
        .sort_values(by="name")
        .reset_index(drop=True)
    )

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    out_path = out_dir / f"Лист_отгрузки_{account_name}_{timestamp}.xlsx"

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Сводка к сборке", index=False)
        df_sorted.to_excel(writer, sheet_name="Все отправления", index=False)

        for sheet_name in ["Сводка к сборке", "Все отправления"]:
            ws = writer.sheets[sheet_name]
            _style_header(ws)
            _autofit_columns(ws)

    return out_path


def _style_header(ws) -> None:
    bold = Font(bold=True)
    border = Border(bottom=Side(style="thin"))
    for cell in ws[1]:
        cell.font = bold
        cell.alignment = Alignment(horizontal="center")
        cell.border = border


def _autofit_columns(ws) -> None:
    for i, col in enumerate(ws.columns, start=1):
        max_len = max((len(str(c.value)) if c.value is not None else 0) for c in col)
        ws.column_dimensions[get_column_letter(i)].width = min(max(max_len + 2, 10), 50)


def ordered_posting_numbers(df: pd.DataFrame) -> list[str]:
    """
    Определяет порядок отправлений для печати бирок так, чтобы он совпадал
    с группировкой листа сборки (по наименованию товара). Если в одном
    отправлении несколько разных товаров, за ключ сортировки берётся
    первое по алфавиту наименование внутри отправления — так отправление
    попадает в бирках рядом с той же группой, что и в сводке к сборке.
    """
    df_sorted = df.sort_values(by=["name", "offer_id"], kind="stable")
    order = df_sorted.groupby("posting_number", sort=False).ngroup()
    unique_postings = (
        df_sorted.assign(_order=order)
        .drop_duplicates(subset=["posting_number"])
        .sort_values("_order")["posting_number"]
        .tolist()
    )
    return unique_postings


def save_labels_pdf(client: OzonClient, posting_numbers: list[str], output_dir: str, account_name: str) -> Path:
    """
    Порядок в итоговом PDF соответствует порядку posting_numbers — передавай
    список, уже отсортированный через ordered_posting_numbers(), чтобы бирки
    шли в том же порядке, что и группы в листе сборки.
    """
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    pdf_bytes = client.get_package_labels_pdf(posting_numbers)

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    out_path = out_dir / f"Бирки_{account_name}_{timestamp}.pdf"
    out_path.write_bytes(pdf_bytes)
    return out_path
