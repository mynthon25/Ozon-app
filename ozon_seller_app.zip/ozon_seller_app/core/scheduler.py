"""
scheduler.py
Фоновый планировщик: для каждого кабинета со своим cron-расписанием
запускает сбор заказов и формирование листа отгрузки + бирок.
"""
from __future__ import annotations

import logging
from typing import Callable

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from core.api_client import OzonClient
from core.config_manager import Account, ConfigManager
from core.orders import fetch_orders_dataframe
from core.shipment import build_shipment_sheet, save_labels_pdf, ordered_posting_numbers

logger = logging.getLogger("scheduler")


class JobRunner:
    """Инкапсулирует один цикл 'собрать заказы -> сформировать файлы' для аккаунта."""

    def __init__(self, account: Account, on_result: Callable[[Account, str], None] | None = None):
        self.account = account
        self.on_result = on_result

    def run(self) -> None:
        try:
            client = OzonClient(self.account)
            df = fetch_orders_dataframe(client)
            if df.empty:
                logger.info("Кабинет %s: новых заказов нет", self.account.name)
                if self.on_result:
                    self.on_result(self.account, "Новых заказов нет")
                return

            output_dir = self.account.output_dir or "./output"
            sheet_path = build_shipment_sheet(df, output_dir, self.account.name)

            posting_numbers = ordered_posting_numbers(df)
            labels_path = save_labels_pdf(client, posting_numbers, output_dir, self.account.name)

            msg = f"Готово: {sheet_path.name}, {labels_path.name}"
            logger.info("Кабинет %s: %s", self.account.name, msg)
            if self.on_result:
                self.on_result(self.account, msg)
        except Exception as e:
            logger.exception("Ошибка при обработке кабинета %s", self.account.name)
            if self.on_result:
                self.on_result(self.account, f"Ошибка: {e}")


class SchedulerService:
    def __init__(self, config: ConfigManager, on_result: Callable[[Account, str], None] | None = None):
        self.config = config
        self.on_result = on_result
        self.scheduler = BackgroundScheduler()
        self._job_ids: dict[str, str] = {}

    def start(self) -> None:
        self.reload_jobs()
        self.scheduler.start()

    def reload_jobs(self) -> None:
        """Пересобирает задания на основе текущего списка аккаунтов и их cron-расписаний."""
        for job_id in list(self._job_ids.values()):
            if self.scheduler.get_job(job_id):
                self.scheduler.remove_job(job_id)
        self._job_ids.clear()

        for account in self.config.accounts:
            if not account.schedule_cron:
                continue
            runner = JobRunner(account, self.on_result)
            job = self.scheduler.add_job(
                runner.run,
                CronTrigger.from_crontab(account.schedule_cron),
                id=f"job_{account.name}",
                replace_existing=True,
            )
            self._job_ids[account.name] = job.id
            logger.info("Запланировано задание для %s: %s", account.name, account.schedule_cron)

    def run_now(self, account: Account) -> None:
        JobRunner(account, self.on_result).run()

    def shutdown(self) -> None:
        self.scheduler.shutdown(wait=False)
