"""
main_window.py
Простой GUI: список кабинетов слева, действия и лог справа.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTime
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QPushButton,
    QLabel, QTextEdit, QFileDialog, QLineEdit, QFormLayout, QDialog,
    QDialogButtonBox, QMessageBox, QTableWidget, QTableWidgetItem, QComboBox,
    QHeaderView, QStackedWidget, QSpinBox, QTimeEdit
)

from core.api_client import OzonClient
from core.config_manager import Account, ConfigManager
from core.orders import fetch_orders_dataframe
from core.shipment import build_shipment_sheet, save_labels_pdf, ordered_posting_numbers
from core.stock import export_stocks_to_excel, update_stocks_from_excel, build_mapping_plan, apply_confirmed_mapping_and_update
from core.scheduler import SchedulerService


class WorkerThread(QThread):
    """Выполняет долгие операции (запросы к API) в фоне, чтобы не подвешивать GUI."""
    finished_ok = pyqtSignal(str)
    finished_err = pyqtSignal(str)

    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            result = self.func(*self.args, **self.kwargs)
            self.finished_ok.emit(str(result))
        except Exception as e:
            self.finished_err.emit(str(e))


class ConnectionTestThread(QThread):
    """Проверяет Client-Id/Api-Key и параллельно тянет список складов кабинета."""
    done = pyqtSignal(list)     # список складов при успехе
    failed = pyqtSignal(str)

    def __init__(self, client_id: str, api_key: str):
        super().__init__()
        self.client_id = client_id
        self.api_key = api_key

    def run(self):
        try:
            temp_account = Account(name="__test__", client_id=self.client_id, api_key=self.api_key)
            client = OzonClient(temp_account)
            result = client.test_connection()
            self.done.emit(result["warehouses"])
        except Exception as e:
            self.failed.emit(str(e))


class PlanThread(QThread):
    """
    Фоновый поток для build_mapping_plan — в отличие от WorkerThread,
    передаёт результат как есть (объект, не str), т.к. дальше нужен доступ
    к user_df и спискам кандидатов, а не текстовое представление.
    """
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, account: Account, file_path: str):
        super().__init__()
        self.account = account
        self.file_path = file_path

    def run(self):
        try:
            client = OzonClient(self.account)
            plan = build_mapping_plan(client, self.account, self.file_path)
            self.done.emit(plan)
        except Exception as e:
            self.failed.emit(str(e))


class AccountDialog(QDialog):
    """
    Диалог добавления/редактирования кабинета.
    Порядок работы: вводишь Client-Id/Api-Key -> «Проверить соединение» ->
    если всё ок, подтягивается список складов кабинета — выбираешь нужный
    из выпадающего списка (руками id склада вводить не нужно).
    Расписание задаётся понятными вариантами, без cron-синтаксиса.
    """

    def __init__(self, parent=None, account: Account | None = None):
        super().__init__(parent)
        self.setWindowTitle("Кабинет Ozon Seller")
        self.resize(480, 420)
        self._warehouses: list[dict] = []

        self.name_edit = QLineEdit(account.name if account else "")
        self.client_id_edit = QLineEdit(account.client_id if account else "")
        self.api_key_edit = QLineEdit(account.api_key if account else "")
        self.api_key_edit.setEchoMode(QLineEdit.EchoMode.Password)

        self.test_btn = QPushButton("Проверить соединение")
        self.test_btn.clicked.connect(self._test_connection)
        self.connection_status = QLabel("Соединение не проверено")

        self.warehouse_combo = QComboBox()
        self.warehouse_combo.setEnabled(False)
        self.warehouse_combo.setPlaceholderText("Сначала проверь соединение")

        self.output_dir_edit = QLineEdit(account.output_dir if account and account.output_dir else "./output")
        browse_btn = QPushButton("Обзор...")
        browse_btn.clicked.connect(self._browse_dir)

        form = QFormLayout()
        form.addRow("Название кабинета:", self.name_edit)
        form.addRow("Client-Id:", self.client_id_edit)
        form.addRow("Api-Key:", self.api_key_edit)
        form.addRow("", self.test_btn)
        form.addRow("Статус:", self.connection_status)
        form.addRow("Склад:", self.warehouse_combo)

        out_row = QHBoxLayout()
        out_row.addWidget(self.output_dir_edit)
        out_row.addWidget(browse_btn)
        form.addRow("Папка для файлов:", out_row)

        # -- расписание, понятное пользователю ------------------------------
        self.schedule_mode_combo = QComboBox()
        self.schedule_mode_combo.addItems([
            "Без автосбора (только вручную)",
            "Через промежуток времени",
            "В конкретное время каждый день",
        ])
        self.schedule_mode_combo.currentIndexChanged.connect(self._on_schedule_mode_changed)
        form.addRow("Автосбор заказов:", self.schedule_mode_combo)

        self.schedule_stack = QStackedWidget()

        empty_page = QWidget()
        self.schedule_stack.addWidget(empty_page)  # индекс 0 — "без автосбора"

        interval_page = QWidget()
        interval_layout = QHBoxLayout(interval_page)
        interval_layout.setContentsMargins(0, 0, 0, 0)
        interval_layout.addWidget(QLabel("Каждые"))
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(5, 1440)
        self.interval_spin.setValue(30)
        self.interval_spin.setSuffix(" мин")
        interval_layout.addWidget(self.interval_spin)
        interval_layout.addStretch()
        self.schedule_stack.addWidget(interval_page)  # индекс 1 — интервал

        times_page = QWidget()
        times_layout = QVBoxLayout(times_page)
        times_layout.setContentsMargins(0, 0, 0, 0)
        self.times_list = QListWidget()
        times_layout.addWidget(self.times_list)
        times_row = QHBoxLayout()
        self.time_picker = QTimeEdit(QTime(9, 0))
        self.time_picker.setDisplayFormat("HH:mm")
        add_time_btn = QPushButton("Добавить время")
        remove_time_btn = QPushButton("Удалить выбранное")
        add_time_btn.clicked.connect(self._add_time)
        remove_time_btn.clicked.connect(self._remove_time)
        times_row.addWidget(self.time_picker)
        times_row.addWidget(add_time_btn)
        times_row.addWidget(remove_time_btn)
        times_layout.addLayout(times_row)
        self.schedule_stack.addWidget(times_page)  # индекс 2 — конкретное время

        form.addRow("", self.schedule_stack)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.setLayout(layout)

        # -- предзаполнение при редактировании существующего кабинета -------
        if account:
            if account.warehouse_id and account.warehouse_name:
                self.warehouse_combo.addItem(account.warehouse_name, userData=account.warehouse_id)
                self.warehouse_combo.setEnabled(True)
                self.connection_status.setText("✓ Ранее подключено — нажми «Проверить соединение», чтобы обновить список складов")

            if account.schedule_mode == "interval" and account.schedule_interval_minutes:
                self.schedule_mode_combo.setCurrentIndex(1)
                self.interval_spin.setValue(account.schedule_interval_minutes)
            elif account.schedule_mode == "daily_times" and account.schedule_times:
                self.schedule_mode_combo.setCurrentIndex(2)
                for t in account.schedule_times:
                    self.times_list.addItem(t)
            else:
                self.schedule_mode_combo.setCurrentIndex(0)

    def _on_schedule_mode_changed(self, index: int):
        self.schedule_stack.setCurrentIndex(index)

    def _add_time(self):
        t = self.time_picker.time().toString("HH:mm")
        existing = [self.times_list.item(i).text() for i in range(self.times_list.count())]
        if t not in existing:
            self.times_list.addItem(t)

    def _remove_time(self):
        row = self.times_list.currentRow()
        if row >= 0:
            self.times_list.takeItem(row)

    def _browse_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Выберите папку")
        if d:
            self.output_dir_edit.setText(d)

    def _test_connection(self):
        client_id = self.client_id_edit.text().strip()
        api_key = self.api_key_edit.text().strip()
        if not client_id or not api_key:
            QMessageBox.warning(self, "Ошибка", "Заполни Client-Id и Api-Key")
            return

        self.test_btn.setEnabled(False)
        self.connection_status.setText("Проверяю соединение...")

        self._test_thread = ConnectionTestThread(client_id, api_key)
        self._test_thread.done.connect(self._on_connection_ok)
        self._test_thread.failed.connect(self._on_connection_failed)
        self._test_thread.start()

    def _on_connection_ok(self, warehouses: list[dict]):
        self.test_btn.setEnabled(True)
        self._warehouses = warehouses
        self.warehouse_combo.clear()

        if not warehouses:
            self.connection_status.setText("✓ Соединение успешно, но складов в кабинете не найдено")
            self.warehouse_combo.setEnabled(False)
            return

        for wh in warehouses:
            label = wh.get("name") or f"Склад {wh.get('warehouse_id')}"
            self.warehouse_combo.addItem(label, userData=wh.get("warehouse_id"))
        self.warehouse_combo.setEnabled(True)
        self.connection_status.setText(f"✓ Соединение успешно, найдено складов: {len(warehouses)}")

    def _on_connection_failed(self, error: str):
        self.test_btn.setEnabled(True)
        self.connection_status.setText(f"✗ Ошибка: {error}")
        QMessageBox.warning(self, "Не удалось подключиться", error)

    def get_account(self) -> Account:
        warehouse_id = self.warehouse_combo.currentData()
        warehouse_name = self.warehouse_combo.currentText() if warehouse_id else None

        mode_index = self.schedule_mode_combo.currentIndex()
        schedule_mode = None
        schedule_interval_minutes = None
        schedule_times = None
        if mode_index == 1:
            schedule_mode = "interval"
            schedule_interval_minutes = self.interval_spin.value()
        elif mode_index == 2:
            schedule_mode = "daily_times"
            schedule_times = [self.times_list.item(i).text() for i in range(self.times_list.count())]
            if not schedule_times:
                schedule_mode = None

        return Account(
            name=self.name_edit.text().strip(),
            client_id=self.client_id_edit.text().strip(),
            api_key=self.api_key_edit.text().strip(),
            warehouse_id=warehouse_id,
            warehouse_name=warehouse_name,
            output_dir=self.output_dir_edit.text().strip() or "./output",
            schedule_mode=schedule_mode,
            schedule_interval_minutes=schedule_interval_minutes,
            schedule_times=schedule_times,
        )


class MappingReviewDialog(QDialog):
    """
    Показывает только НОВЫЕ (ещё не сопоставленные ранее) названия товаров
    из файла пользователя, с предложенными кандидатами из каталога Ozon.
    Пользователь выбирает правильный вариант или "Не сопоставлять".
    Уже подтверждённые ранее соответствия сюда не попадают — применяются молча.
    """
    SKIP_LABEL = "— не сопоставлять —"

    def __init__(self, parent, needs_review: list[dict]):
        super().__init__(parent)
        self.setWindowTitle("Подтвердите сопоставление новых товаров")
        self.resize(760, 420)
        self.needs_review = needs_review

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Ozon предложил наиболее похожие товары по каждому новому названию.\n"
            "Проверь и выбери правильный вариант (или «не сопоставлять», чтобы пропустить этот товар)."
        ))

        self.table = QTableWidget(len(needs_review), 2)
        self.table.setHorizontalHeaderLabels(["Название в вашем файле", "Соответствие в Ozon"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        self.combos: list[QComboBox] = []
        for row, item in enumerate(needs_review):
            self.table.setItem(row, 0, QTableWidgetItem(item["user_name"]))

            combo = QComboBox()
            for cand in item["candidates"]:
                label = f"{cand['name']}  (offer_id: {cand['offer_id']}, похожесть {int(cand['score']*100)}%)"
                combo.addItem(label, userData=cand)
            combo.addItem(self.SKIP_LABEL, userData=None)
            if not item["candidates"]:
                combo.setCurrentText(self.SKIP_LABEL)
            self.combos.append(combo)
            self.table.setCellWidget(row, 1, combo)

        layout.addWidget(self.table)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_selected_mapping(self) -> dict:
        """Возвращает {user_name: {"offer_id":..., "ozon_name":...}} только для выбранных (не пропущенных)."""
        result = {}
        for row, item in enumerate(self.needs_review):
            data = self.combos[row].currentData()
            if data:
                result[item["user_name"]] = {"offer_id": data["offer_id"], "ozon_name": data["name"]}
        return result


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ozon Seller — сбор заказов и остатков")
        self.resize(900, 600)

        self.config = ConfigManager()
        self.scheduler = SchedulerService(self.config, on_result=self._on_job_result)
        self.scheduler.start()

        self._build_ui()
        self._refresh_account_list()

    # ---------------------------------------------------------------- UI --
    def _build_ui(self):
        central = QWidget()
        root = QHBoxLayout(central)

        # Левая колонка: список кабинетов
        left = QVBoxLayout()
        left.addWidget(QLabel("Кабинеты:"))
        self.account_list = QListWidget()
        self.account_list.currentRowChanged.connect(self._on_account_selected)
        left.addWidget(self.account_list)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("Добавить")
        edit_btn = QPushButton("Изменить")
        del_btn = QPushButton("Удалить")
        add_btn.clicked.connect(self._add_account)
        edit_btn.clicked.connect(self._edit_account)
        del_btn.clicked.connect(self._delete_account)
        btn_row.addWidget(add_btn)
        btn_row.addWidget(edit_btn)
        btn_row.addWidget(del_btn)
        left.addLayout(btn_row)

        # Правая колонка: действия + лог
        right = QVBoxLayout()
        right.addWidget(QLabel("Действия для выбранного кабинета:"))

        action_row = QHBoxLayout()
        self.fetch_btn = QPushButton("Собрать заказы сейчас")
        self.export_stock_btn = QPushButton("Выгрузить остатки в Excel")
        self.import_stock_btn = QPushButton("Обновить остатки (offer_id)")
        self.import_mapped_stock_btn = QPushButton("Обновить остатки из файла (по названиям)")
        self.fetch_btn.clicked.connect(self._fetch_orders_now)
        self.export_stock_btn.clicked.connect(self._export_stocks)
        self.import_stock_btn.clicked.connect(self._import_stocks)
        self.import_mapped_stock_btn.clicked.connect(self._import_stocks_by_name)
        action_row.addWidget(self.fetch_btn)
        action_row.addWidget(self.export_stock_btn)
        action_row.addWidget(self.import_stock_btn)
        action_row.addWidget(self.import_mapped_stock_btn)
        right.addLayout(action_row)

        right.addWidget(QLabel("Лог:"))
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        right.addWidget(self.log_view)

        root.addLayout(left, 1)
        root.addLayout(right, 2)
        self.setCentralWidget(central)

    def _log(self, text: str):
        self.log_view.append(text)

    # ---------------------------------------------------------- аккаунты --
    def _refresh_account_list(self):
        self.account_list.clear()
        for a in self.config.accounts:
            if a.schedule_mode == "interval" and a.schedule_interval_minutes:
                sched_text = f"каждые {a.schedule_interval_minutes} мин"
            elif a.schedule_mode == "daily_times" and a.schedule_times:
                sched_text = "в " + ", ".join(a.schedule_times)
            else:
                sched_text = ""
            label = a.name + (f"  [{sched_text}]" if sched_text else "")
            self.account_list.addItem(label)

    def _current_account(self) -> Account | None:
        row = self.account_list.currentRow()
        if row < 0 or row >= len(self.config.accounts):
            return None
        return self.config.accounts[row]

    def _on_account_selected(self, _row: int):
        pass

    def _add_account(self):
        dlg = AccountDialog(self)
        if dlg.exec():
            acc = dlg.get_account()
            if not acc.name or not acc.client_id or not acc.api_key:
                QMessageBox.warning(self, "Ошибка", "Заполните название, Client-Id и Api-Key")
                return
            self.config.add_account(acc)
            self.scheduler.reload_jobs()
            self._refresh_account_list()

    def _edit_account(self):
        row = self.account_list.currentRow()
        if row < 0:
            return
        dlg = AccountDialog(self, self.config.accounts[row])
        if dlg.exec():
            self.config.update_account(row, dlg.get_account())
            self.scheduler.reload_jobs()
            self._refresh_account_list()

    def _delete_account(self):
        row = self.account_list.currentRow()
        if row < 0:
            return
        confirm = QMessageBox.question(self, "Подтверждение", "Удалить выбранный кабинет?")
        if confirm == QMessageBox.StandardButton.Yes:
            self.config.remove_account(row)
            self.scheduler.reload_jobs()
            self._refresh_account_list()

    # ------------------------------------------------------------ действия --
    def _fetch_orders_now(self):
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        self._log(f"[{acc.name}] Сбор заказов...")
        self._thread = WorkerThread(self.scheduler.run_now, acc)
        self._thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] Готово"))
        self._thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._thread.start()

    def _export_stocks(self):
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        self._log(f"[{acc.name}] Выгрузка остатков...")

        def job():
            client = OzonClient(acc)
            path = export_stocks_to_excel(client, acc.output_dir or "./output", acc.name)
            return path

        self._thread = WorkerThread(job)
        self._thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] Остатки сохранены: {r}"))
        self._thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._thread.start()

    def _import_stocks(self):
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Выберите Excel с остатками", filter="Excel (*.xlsx)")
        if not path:
            return
        self._log(f"[{acc.name}] Обновление остатков из {path}...")

        def job():
            client = OzonClient(acc)
            return update_stocks_from_excel(client, acc, path)

        self._thread = WorkerThread(job)
        self._thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] Остатки обновлены: {r}"))
        self._thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._thread.start()

    def _import_stocks_by_name(self):
        """
        Обновление остатков из файла пользователя, где товары названы
        произвольно (не совпадает с offer_id в Ozon). Сначала строим план
        сопоставления (каталог Ozon + похожесть названий), затем показываем
        диалог подтверждения только для новых названий, затем отправляем
        обновление.
        """
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Выберите файл остатков (Excel)", filter="Excel (*.xlsx)")
        if not path:
            return

        self._log(f"[{acc.name}] Загружаю каталог Ozon и сопоставляю названия из файла...")

        # PlanThread возвращает готовый объект (не строку), поэтому используем
        # отдельный поток с сигналом object, а не общий WorkerThread.
        self._plan_thread = PlanThread(acc, path)
        self._plan_thread.done.connect(lambda plan: self._on_plan_ready(acc, plan))
        self._plan_thread.failed.connect(lambda e: self._log(f"[{acc.name}] Ошибка сопоставления: {e}"))
        self._plan_thread.start()

    def _on_plan_ready(self, acc: Account, plan: dict):
        needs_review = plan["needs_review"]
        already_mapped = plan["already_mapped"]
        user_df = plan["user_df"]

        self._log(
            f"[{acc.name}] Уже сопоставлено ранее: {len(already_mapped)}. "
            f"Новых названий на подтверждение: {len(needs_review)}."
        )

        confirmed: dict[str, dict] = {
            m["user_name"]: {"offer_id": m["offer_id"], "ozon_name": m["ozon_name"]}
            for m in already_mapped
        }

        if needs_review:
            dlg = MappingReviewDialog(self, needs_review)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                self._log(f"[{acc.name}] Сопоставление отменено пользователем")
                return
            confirmed.update(dlg.get_selected_mapping())

        self._log(f"[{acc.name}] Отправляю обновление остатков в Ozon...")

        def apply_job():
            client = OzonClient(acc)
            return apply_confirmed_mapping_and_update(client, acc, user_df, confirmed)

        self._apply_thread = WorkerThread(apply_job)
        self._apply_thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] {r}"))
        self._apply_thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._apply_thread.start()

    def _on_job_result(self, account: Account, message: str):
        # Вызывается из фонового планировщика (другой поток) — просто логируем.
        self._log(f"[{account.name}] (по расписанию) {message}")

    def closeEvent(self, event):
        self.scheduler.shutdown()
        super().closeEvent(event)
