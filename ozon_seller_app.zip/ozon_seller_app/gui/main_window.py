"""
main_window.py
Простой GUI: список кабинетов слева, действия и лог справа.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QPushButton,
    QLabel, QTextEdit, QFileDialog, QLineEdit, QFormLayout, QDialog,
    QDialogButtonBox, QMessageBox, QTableWidget, QTableWidgetItem, QComboBox,
    QHeaderView
)

from core.api_client import OzonClient
from core.config_manager import Account, ConfigManager
from core.orders import fetch_orders_dataframe
from core.shipment import build_shipment_sheet, save_labels_pdf, ordered_posting_numbers
from core.stock import export_stocks_to_excel, update_stocks_from_excel, build_mapping_plan, apply_confirmed_mapping_and_update
from core.scheduler import SchedulerService


class WorkerThread(QThread):
    """Выполняет долгие операции (запросы к API) в фоне, чтобы не подвешивать GUI."""
    finished_ok = pyqtSignal(str)
    finished_err = pyqtSignal(str)

    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            result = self.func(*self.args, **self.kwargs)
            self.finished_ok.emit(str(result))
        except Exception as e:
            self.finished_err.emit(str(e))


class PlanThread(QThread):
    """
    Фоновый поток для build_mapping_plan — в отличие от WorkerThread,
    передаёт результат как есть (объект, не str), т.к. дальше нужен доступ
    к user_df и спискам кандидатов, а не текстовое представление.
    """
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, account: Account, file_path: str):
        super().__init__()
        self.account = account
        self.file_path = file_path

    def run(self):
        try:
            client = OzonClient(self.account)
            plan = build_mapping_plan(client, self.account, self.file_path)
            self.done.emit(plan)
        except Exception as e:
            self.failed.emit(str(e))


class AccountDialog(QDialog):
    """Диалог добавления/редактирования кабинета."""

    def __init__(self, parent=None, account: Account | None = None):
        super().__init__(parent)
        self.setWindowTitle("Кабинет Ozon Seller")

        self.name_edit = QLineEdit(account.name if account else "")
        self.client_id_edit = QLineEdit(account.client_id if account else "")
        self.api_key_edit = QLineEdit(account.api_key if account else "")
        self.api_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.warehouse_edit = QLineEdit(str(account.warehouse_id) if account and account.warehouse_id else "")
        self.cron_edit = QLineEdit(account.schedule_cron if account and account.schedule_cron else "")
        self.cron_edit.setPlaceholderText("напр. */30 * * * *  (каждые 30 минут)")
        self.output_dir_edit = QLineEdit(account.output_dir if account and account.output_dir else "./output")

        browse_btn = QPushButton("Обзор...")
        browse_btn.clicked.connect(self._browse_dir)

        form = QFormLayout()
        form.addRow("Название кабинета:", self.name_edit)
        form.addRow("Client-Id:", self.client_id_edit)
        form.addRow("Api-Key:", self.api_key_edit)
        form.addRow("Склад по умолчанию (warehouse_id):", self.warehouse_edit)
        form.addRow("Расписание (cron):", self.cron_edit)

        out_row = QHBoxLayout()
        out_row.addWidget(self.output_dir_edit)
        out_row.addWidget(browse_btn)
        form.addRow("Папка для файлов:", out_row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.setLayout(layout)

    def _browse_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Выберите папку")
        if d:
            self.output_dir_edit.setText(d)

    def get_account(self) -> Account:
        wh = self.warehouse_edit.text().strip()
        return Account(
            name=self.name_edit.text().strip(),
            client_id=self.client_id_edit.text().strip(),
            api_key=self.api_key_edit.text().strip(),
            warehouse_id=int(wh) if wh else None,
            schedule_cron=self.cron_edit.text().strip() or None,
            output_dir=self.output_dir_edit.text().strip() or "./output",
        )


class MappingReviewDialog(QDialog):
    """
    Показывает только НОВЫЕ (ещё не сопоставленные ранее) названия товаров
    из файла пользователя, с предложенными кандидатами из каталога Ozon.
    Пользователь выбирает правильный вариант или "Не сопоставлять".
    Уже подтверждённые ранее соответствия сюда не попадают — применяются молча.
    """
    SKIP_LABEL = "— не сопоставлять —"

    def __init__(self, parent, needs_review: list[dict]):
        super().__init__(parent)
        self.setWindowTitle("Подтвердите сопоставление новых товаров")
        self.resize(760, 420)
        self.needs_review = needs_review

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Ozon предложил наиболее похожие товары по каждому новому названию.\n"
            "Проверь и выбери правильный вариант (или «не сопоставлять», чтобы пропустить этот товар)."
        ))

        self.table = QTableWidget(len(needs_review), 2)
        self.table.setHorizontalHeaderLabels(["Название в вашем файле", "Соответствие в Ozon"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        self.combos: list[QComboBox] = []
        for row, item in enumerate(needs_review):
            self.table.setItem(row, 0, QTableWidgetItem(item["user_name"]))

            combo = QComboBox()
            for cand in item["candidates"]:
                label = f"{cand['name']}  (offer_id: {cand['offer_id']}, похожесть {int(cand['score']*100)}%)"
                combo.addItem(label, userData=cand)
            combo.addItem(self.SKIP_LABEL, userData=None)
            if not item["candidates"]:
                combo.setCurrentText(self.SKIP_LABEL)
            self.combos.append(combo)
            self.table.setCellWidget(row, 1, combo)

        layout.addWidget(self.table)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_selected_mapping(self) -> dict:
        """Возвращает {user_name: {"offer_id":..., "ozon_name":...}} только для выбранных (не пропущенных)."""
        result = {}
        for row, item in enumerate(self.needs_review):
            data = self.combos[row].currentData()
            if data:
                result[item["user_name"]] = {"offer_id": data["offer_id"], "ozon_name": data["name"]}
        return result


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ozon Seller — сбор заказов и остатков")
        self.resize(900, 600)

        self.config = ConfigManager()
        self.scheduler = SchedulerService(self.config, on_result=self._on_job_result)
        self.scheduler.start()

        self._build_ui()
        self._refresh_account_list()

    # ---------------------------------------------------------------- UI --
    def _build_ui(self):
        central = QWidget()
        root = QHBoxLayout(central)

        # Левая колонка: список кабинетов
        left = QVBoxLayout()
        left.addWidget(QLabel("Кабинеты:"))
        self.account_list = QListWidget()
        self.account_list.currentRowChanged.connect(self._on_account_selected)
        left.addWidget(self.account_list)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("Добавить")
        edit_btn = QPushButton("Изменить")
        del_btn = QPushButton("Удалить")
        add_btn.clicked.connect(self._add_account)
        edit_btn.clicked.connect(self._edit_account)
        del_btn.clicked.connect(self._delete_account)
        btn_row.addWidget(add_btn)
        btn_row.addWidget(edit_btn)
        btn_row.addWidget(del_btn)
        left.addLayout(btn_row)

        # Правая колонка: действия + лог
        right = QVBoxLayout()
        right.addWidget(QLabel("Действия для выбранного кабинета:"))

        action_row = QHBoxLayout()
        self.fetch_btn = QPushButton("Собрать заказы сейчас")
        self.export_stock_btn = QPushButton("Выгрузить остатки в Excel")
        self.import_stock_btn = QPushButton("Обновить остатки (offer_id)")
        self.import_mapped_stock_btn = QPushButton("Обновить остатки из файла (по названиям)")
        self.fetch_btn.clicked.connect(self._fetch_orders_now)
        self.export_stock_btn.clicked.connect(self._export_stocks)
        self.import_stock_btn.clicked.connect(self._import_stocks)
        self.import_mapped_stock_btn.clicked.connect(self._import_stocks_by_name)
        action_row.addWidget(self.fetch_btn)
        action_row.addWidget(self.export_stock_btn)
        action_row.addWidget(self.import_stock_btn)
        action_row.addWidget(self.import_mapped_stock_btn)
        right.addLayout(action_row)

        right.addWidget(QLabel("Лог:"))
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        right.addWidget(self.log_view)

        root.addLayout(left, 1)
        root.addLayout(right, 2)
        self.setCentralWidget(central)

    def _log(self, text: str):
        self.log_view.append(text)

    # ---------------------------------------------------------- аккаунты --
    def _refresh_account_list(self):
        self.account_list.clear()
        for a in self.config.accounts:
            label = a.name + (f"  [расписание: {a.schedule_cron}]" if a.schedule_cron else "")
            self.account_list.addItem(label)

    def _current_account(self) -> Account | None:
        row = self.account_list.currentRow()
        if row < 0 or row >= len(self.config.accounts):
            return None
        return self.config.accounts[row]

    def _on_account_selected(self, _row: int):
        pass

    def _add_account(self):
        dlg = AccountDialog(self)
        if dlg.exec():
            acc = dlg.get_account()
            if not acc.name or not acc.client_id or not acc.api_key:
                QMessageBox.warning(self, "Ошибка", "Заполните название, Client-Id и Api-Key")
                return
            self.config.add_account(acc)
            self.scheduler.reload_jobs()
            self._refresh_account_list()

    def _edit_account(self):
        row = self.account_list.currentRow()
        if row < 0:
            return
        dlg = AccountDialog(self, self.config.accounts[row])
        if dlg.exec():
            self.config.update_account(row, dlg.get_account())
            self.scheduler.reload_jobs()
            self._refresh_account_list()

    def _delete_account(self):
        row = self.account_list.currentRow()
        if row < 0:
            return
        confirm = QMessageBox.question(self, "Подтверждение", "Удалить выбранный кабинет?")
        if confirm == QMessageBox.StandardButton.Yes:
            self.config.remove_account(row)
            self.scheduler.reload_jobs()
            self._refresh_account_list()

    # ------------------------------------------------------------ действия --
    def _fetch_orders_now(self):
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        self._log(f"[{acc.name}] Сбор заказов...")
        self._thread = WorkerThread(self.scheduler.run_now, acc)
        self._thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] Готово"))
        self._thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._thread.start()

    def _export_stocks(self):
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        self._log(f"[{acc.name}] Выгрузка остатков...")

        def job():
            client = OzonClient(acc)
            path = export_stocks_to_excel(client, acc.output_dir or "./output", acc.name)
            return path

        self._thread = WorkerThread(job)
        self._thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] Остатки сохранены: {r}"))
        self._thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._thread.start()

    def _import_stocks(self):
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Выберите Excel с остатками", filter="Excel (*.xlsx)")
        if not path:
            return
        self._log(f"[{acc.name}] Обновление остатков из {path}...")

        def job():
            client = OzonClient(acc)
            return update_stocks_from_excel(client, acc, path)

        self._thread = WorkerThread(job)
        self._thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] Остатки обновлены: {r}"))
        self._thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._thread.start()

    def _import_stocks_by_name(self):
        """
        Обновление остатков из файла пользователя, где товары названы
        произвольно (не совпадает с offer_id в Ozon). Сначала строим план
        сопоставления (каталог Ozon + похожесть названий), затем показываем
        диалог подтверждения только для новых названий, затем отправляем
        обновление.
        """
        acc = self._current_account()
        if not acc:
            QMessageBox.warning(self, "Ошибка", "Выберите кабинет")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Выберите файл остатков (Excel)", filter="Excel (*.xlsx)")
        if not path:
            return

        self._log(f"[{acc.name}] Загружаю каталог Ozon и сопоставляю названия из файла...")

        # PlanThread возвращает готовый объект (не строку), поэтому используем
        # отдельный поток с сигналом object, а не общий WorkerThread.
        self._plan_thread = PlanThread(acc, path)
        self._plan_thread.done.connect(lambda plan: self._on_plan_ready(acc, plan))
        self._plan_thread.failed.connect(lambda e: self._log(f"[{acc.name}] Ошибка сопоставления: {e}"))
        self._plan_thread.start()

    def _on_plan_ready(self, acc: Account, plan: dict):
        needs_review = plan["needs_review"]
        already_mapped = plan["already_mapped"]
        user_df = plan["user_df"]

        self._log(
            f"[{acc.name}] Уже сопоставлено ранее: {len(already_mapped)}. "
            f"Новых названий на подтверждение: {len(needs_review)}."
        )

        confirmed: dict[str, dict] = {
            m["user_name"]: {"offer_id": m["offer_id"], "ozon_name": m["ozon_name"]}
            for m in already_mapped
        }

        if needs_review:
            dlg = MappingReviewDialog(self, needs_review)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                self._log(f"[{acc.name}] Сопоставление отменено пользователем")
                return
            confirmed.update(dlg.get_selected_mapping())

        self._log(f"[{acc.name}] Отправляю обновление остатков в Ozon...")

        def apply_job():
            client = OzonClient(acc)
            return apply_confirmed_mapping_and_update(client, acc, user_df, confirmed)

        self._apply_thread = WorkerThread(apply_job)
        self._apply_thread.finished_ok.connect(lambda r: self._log(f"[{acc.name}] {r}"))
        self._apply_thread.finished_err.connect(lambda e: self._log(f"[{acc.name}] Ошибка: {e}"))
        self._apply_thread.start()

    def _on_job_result(self, account: Account, message: str):
        # Вызывается из фонового планировщика (другой поток) — просто логируем.
        self._log(f"[{account.name}] (по расписанию) {message}")

    def closeEvent(self, event):
        self.scheduler.shutdown()
        super().closeEvent(event)
